package solution;

import jigsaw.Jigsaw;
import jigsaw.JigsawNode;
import java.util.Vector;


/**
 * 在此类中填充算法，完成重拼图游戏（N-数码问题）
 */
public class Solution extends Jigsaw {

	protected Vector<JigsawNode> oList;
	protected Vector<JigsawNode> cList;
	protected Vector<JigsawNode> sPath;
	private boolean completed = false;
	private int searchedNum = 0;
	
    /**
     * 拼图构造函数
     */
    public Solution() {
    }

    /**
     * 拼图构造函数
     * @param bNode - 初始状态节点
     * @param eNode - 目标状态节点
     */
    public Solution(JigsawNode bNode, JigsawNode eNode) {
        super(bNode, eNode);
    }
    
    
    //
    private boolean calSolutionPath() {
		if (!completed) {
			return false;
		} else {
			JigsawNode jNode = this.currentJNode;
			sPath = new Vector<JigsawNode>();
			while (jNode != null) {
				sPath.addElement(jNode);
				jNode = jNode.getParent();
			}
			return true;
		}
	}
    
    //find the adjacent node with jNode which have been not visit
    private Vector<JigsawNode> findFollowJNodes(JigsawNode jNode) {
		Vector<JigsawNode> followJNodes = new Vector<JigsawNode>();
		JigsawNode tempJNode;
		for(int i=0; i<4; i++){
			tempJNode = new JigsawNode(jNode);
			if(tempJNode.move(i) && !this.cList.contains(tempJNode) && !this.oList.contains(tempJNode))
				followJNodes.addElement(tempJNode);
		}
		return followJNodes;
	}
    
    
    public final String getsPath() {
        String str = new String();
        str += "Begin->";
        if (completed) {
            for (int i = sPath.size() - 1; i >= 0; i--) {
                str += sPath.get(i).toString() + "->";
            }
            str += "End";
        } else {
            str = "Jigsaw Not Completed.";
        }
        return str;
    }
    

    /**
     *（实验一）广度优先搜索算法，求指定5*5拼图（24-数码问题）的最优解
     * 填充此函数，可在Solution类中添加其他函数，属性
     * @param bNode - 初始状态节点
     * @param eNode - 目标状态节点
     * @return 搜索成功时为true,失败为false
     */
    public boolean BFSearch(JigsawNode bNode, JigsawNode eNode) {
    	
    	oList = new Vector<JigsawNode>();
    	cList = new Vector<JigsawNode>();
    	sPath = new Vector<JigsawNode>();
    	this.setBeginJNode(bNode);
    	this.setEndJNode(eNode);
    	Vector<JigsawNode> followJNodes = new Vector<JigsawNode>();

		completed = false;
		searchedNum = 0;
		// (1) 将起始节点放入openList中
		oList.add(bNode);
		
		// (2) 如果openList为空，则搜索失败，问题无解;否则循环直到求解成功
		while (!oList.isEmpty()) {
			// (2-1)访问openList的第一个节点N，置为当前节点currentJNode
			//      若currentJNode为目标节点，则搜索成功，设置完成标记isCompleted为true，计算解路径，退出。
			currentJNode = oList.get(0);
			if (currentJNode.equals(eNode)) {
				completed = true;
				calSolutionPath();
				break;
			}
			// (2-2)从openList中删除节点N,并将其放入closeList中，表示以访问节点			
			oList.remove(0);
			cList.add(currentJNode);
			searchedNum++;
			
			// 记录并显示搜索过程
			//pw.println("Searching.....Number of searched nodes:" + this.closeList.size() + "   Current state:" + this.currentJNode.toString());
			//System.out.println("Searching.....Number of searched nodes:" + this.cList.size() + "   Current state:" + this.currentJNode.toString());			

		// (2-3)寻找所有与currentJNode邻接且未曾被访问的节点，将它们按代价估值从小到大排序插入openList中
			followJNodes = findFollowJNodes(currentJNode);
			while (!followJNodes.isEmpty()) {
				oList.add(followJNodes.get(0));
				followJNodes.remove(0);
			}
			
		}
		
		// *************************************
		//this.printResult(pw);
		//pw.close();
		//System.out.println("Record into " + filePath);
		System.out.println("Jigsaw BFSearch Result:");
        System.out.println("Begin state:" + this.getBeginJNode().toString());
        System.out.println("End state:" + this.getEndJNode().toString());
        //System.out.println("Solution Path: ");
        //System.out.println(this.getsPath());
        //System.out.println("Total number of searched nodes:" + this.getSearchedNodesNum());
        System.out.println("Depth of the current node is:" + this.getCurrentJNode().getNodeDepth());
		return completed;
    }


    /**
     *（Demo+实验二）计算并修改状态节点jNode的代价估计值:f(n)
     * 如 f(n) = s(n). s(n)代表后续节点不正确的数码个数
     * 此函数会改变该节点的estimatedValue属性值
     * 修改此函数，可在Solution类中添加其他函数，属性
     * @param jNode - 要计算代价估计值的节点
     */
    /*public void estimateValue(JigsawNode jNode) {
        int s = 0; // 后续节点不正确的数码个数
        int dimension = JigsawNode.getDimension();
        for (int index = 1; index < dimension * dimension; index++) {
            if (jNode.getNodesState()[index] + 1 != jNode.getNodesState()[index + 1]) {
                s++;
            }
        }
        jNode.setEstimatedValue(s);
    }*/
    
    public void estimateValue(JigsawNode jNode) {
    	int wrongAll = getWrongAll(jNode);
		int dis = getDistance(jNode);
		int restWrongNode = getRestWrongNode(jNode);
		int nodeDepth = jNode.getNodeDepth();
		
		jNode.setEstimatedValue(wrongAll * 0 +
				dis * 8 +
				restWrongNode * 4 +
				nodeDepth * 0);
    }
    
    
    private int getWrongAll(JigsawNode jNode) {
		int wrongNode = 0;
		int dim = jNode.getDimension();
		for (int i = 1; i <= dim * dim; i++) {
			if (jNode.getNodesState()[i] != i && jNode.getNodesState()[i] != 0) {
				wrongNode++;
			}
		}
		return wrongNode;
	}
	
	/**
	 * 所有 放错位的数码与其正确位置的 曼哈顿距离 之和
	 */
	private int getDistance(JigsawNode jNode) {
		int disNode = 0;
		int dim = jNode.getDimension();
		for (int i = 1; i <= dim * dim; i++) {
			if (jNode.getNodesState()[i] != i && jNode.getNodesState()[i] != 0) {
				// calculate the correct location
				int destR = (jNode.getNodesState()[i] - 1) / dim;
				int destC = (jNode.getNodesState()[i] - 1) % dim;

				int curR = (i - 1) / dim;
				int curC = (i - 1) % dim;
				
				disNode += Math.abs(destC - curC) + Math.abs(destR - curR); 
			}
		}
		return disNode;
	}
	
	/**
	 * 后续节点不正确的数码个数
	 * suppose the curNode is right, to find if the node next to it is wrong
	 */
	private int getRestWrongNode(JigsawNode jNode) {
		int restNode = 0;
		int dim = jNode.getDimension();
		
		/*统计横向不正确的后续节点*/
		for (int i = 1; i < dim * dim; i++) {
			if (jNode.getNodesState()[i] + 1 != jNode.getNodesState()[i + 1]) {
				restNode++;
			}
		}
		
		/*统计纵向不正确的后续节点*/
		for (int i = 1; i < dim * (dim - 1); i++) {
			if (jNode.getNodesState()[i] + dim != jNode.getNodesState()[i + dim]) {
				restNode++;
			}
		}
		
		return restNode;
	}
}
